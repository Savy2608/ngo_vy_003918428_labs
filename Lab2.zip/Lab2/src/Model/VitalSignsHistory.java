/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.ArrayList;
/**
 *
 * @author vyngo
 */
public class VitalSignsHistory {
    ArrayList<VitalSigns> history;
    
    public VitalSignsHistory(){
        history = new ArrayList<VitalSigns>();
    }
    
    public VitalSigns addNewVitals(){
        VitalSigns newVs = new VitalSigns();
        history.add(newVs);
        return newVs;
    }
    
    public void removeVital(VitalSigns vs){
        history.remove(vs);
    }
    
    public ArrayList<VitalSigns> getHistory(){
        return history;
    }
}
    
